@extends('layouts.app')

@include('inc.navbar')
<br>
<br>    
@section('content')
    <h1>App</h1>
@endsection