@extends('layouts.app')

@include('inc.navbar')
@section('content')
    <h1>Successfully updated name</h1>
    <h3><a href="/home">Home</a></h3>
@endsection